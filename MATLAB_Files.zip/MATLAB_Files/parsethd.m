function[STEPTABLE]=parsethd()
%This fucntion parses the Spice Error Log file you choose
%and returns a matlab table with the input volatge amplitude steps, 
%the single additional parameter steps (i.e .step aparm Rl list 4 8 16)
%,and the reults of a single measure statement (which should be the
%average power in the load resitor). You should only specify one measure
%statement, the average output power in your spice file.
%You can save each run into separate tables using for example:
%thd_pout_RL=parsethd
%after running a simulation that steps the vin amplitude with a .tran and
%.four command, a step of the output load resistor value, and a measure statement 
%to find the average output power in the load resistor
%
%clear all;
clc
%filename = 'lm386_example.log'
[FileName,PathName] = uigetfile('*.log','Select the LTspice error log file');
filename=fullfile(PathName,FileName)
fileID  = fopen(filename,'r');
text = textscan(fileID,'%s','Delimiter',',');
text = text{1};
fclose(fileID);
%Parse steps,THD
idx = find(contains(text,'Total Harmonic Distortion:'));
thd  = cellfun(@(x) textscan(x,'Total Harmonic Distortion: %f%*[^\n]'),text(idx));
THD = cell2table(thd);
%thdx=cell2mat(thd);
%%
ids = find(contains(text,'.step'));
vin  = cellfun(@(x) textscan(x,'.step %*s%f%*s%*f%*[^\n]','Delimiter','='),text(ids));
VIN=cell2table(vin);
param  = cellfun(@(x) textscan(x,'.step %*s%*f%*s%f%*[^\n]','Delimiter','='),text(ids));
PARAM= cell2table(param);
%merged = table(Step,THD);
numsteps = length(vin);
%%
%% Read Ouput Power Measure Data
formatSpec = '%s%f%.*[^\n\r]';
delimiter = '\t';
% Open the text file.
fileID = fopen(filename, 'r');
    foo = '';
    while ~strncmpi(foo,'Measurement',11)
        foo = fgetl(fileID);
    end
%% Read columns of data according to the format.
dataArray = textscan(fileID, formatSpec, numsteps,'Headerlines',1,'Delimiter', delimiter);
%% Close the text file.
fclose(fileID);
%
Po = cell2mat(dataArray(2));
Pout = array2table(Po,'VariableNames',{'Pout'});
vind=str2double(VIN);
STEPTABLE = [VIN PARAM THD Pout];
end

